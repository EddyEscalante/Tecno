<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\Cumodulo */

$this->title = 'Update Cumodulo: ' . $model->id_cu;
$this->params['breadcrumbs'][] = ['label' => 'Cumodulos', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_cu, 'url' => ['view', 'id_cu' => $model->id_cu, 'id_modulo' => $model->id_modulo]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="cumodulo-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
