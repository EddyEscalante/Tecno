<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use backend\models\Tipo;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model backend\models\Usuario */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="usuario-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'ci')->textInput() ?>

    <?= $form->field($model, 'nombres')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'apellidos')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'telefono')->textInput() ?>

    <?= $form->field($model, 'estado')->textInput() ?>
    
    <p> registrando el grupo del usuario </p>
    
    <?= $form->field($tipousuario, 'id_tipo')->dropDownList(
        ArrayHelper::map(Tipo::find()->all(),'id','nombre'),
            ['prompt'=>'Escoja el grupo Asociado']
            ) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
