<?php

use backend\models\Tipo;
use common\models\User;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\Usuario */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="usuario-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'ci')->textInput() ?>

    <?= $form->field($model, 'nombres')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'apellidos')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'telefono')->textInput() ?>

    <?= $form->field($model, 'estado')->textInput() ?>

    <?= $form->field($model, 'fk_user')->dropDownList(
        ArrayHelper::map(User::find()->all(),'id','username'),
            ['prompt'=>'Escoja id user']
            ) ?>
    
    <p> registrando el grupo del usuario </p>
    
    <?= $form->field($tipousuario, 'id_tipo')->dropDownList(
        ArrayHelper::map(Tipo::find()->all(),'id','nombre'),
            ['prompt'=>'Escoja el grupo Asociado']
            ) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
