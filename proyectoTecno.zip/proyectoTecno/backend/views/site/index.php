<?php

/* @var $this yii\web\View */

$this->title = 'VideoClub ScorpioN';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Bienvenido al VideoClub ScorpioN</h1>
        
        
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Novedades!</h2>

                <p>Olvidate de ir hasta la tienda para alquilar las peliculas de tu agrado.</p>
                
            </div>
            <div class="col-lg-4">
                <h2>Que es?</h2>

                <p>Usa nuestro servicio y veras como se te facilita la vida.</p>

                
            </div>
            <div class="col-lg-4">
                <h2>Otros</h2>

                <p>Muy sencillo de usar y muchas cosas mas!.</p>

                
            </div>
        </div>

    </div>
</div>
