<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\Cutipo */

$this->title = 'Update Cutipo: ' . $model->id_tipo;
$this->params['breadcrumbs'][] = ['label' => 'Cutipos', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_tipo, 'url' => ['view', 'id_tipo' => $model->id_tipo, 'id_cu' => $model->id_cu]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="cutipo-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
