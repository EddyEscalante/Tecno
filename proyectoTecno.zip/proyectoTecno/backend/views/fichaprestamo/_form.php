<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use backend\models\Usuario;
use backend\models\Video;
/* @var $this yii\web\View */
/* @var $model backend\models\Fichaprestamo */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="fichaprestamo-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nro')->textInput() ?>
    
    <?= $form->field($model, 'ci_usuario')->dropDownList(
        ArrayHelper::map(Usuario::find()->all(),'ci','ci'),
            ['prompt'=>'Escoja el CI del Usuario']
            ) ?>

    <?= $form->field($model, 'nombre')->dropDownList(
        ArrayHelper::map(Usuario::find()->all(),'nombres','nombres'),
            ['prompt'=>'Escoja el nombre del Usuario']
            ) ?>

    <?= $form->field($model, 'direccion')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'dias')->textInput() ?>

    <?= $form->field($model, 'fecha')->textInput() ?>
    
    
    <!-- Creando el detalle de la ficha -->
    
    <p> Registrando el detalle </p>

    <?= $form->field($detalle, 'id_video')->dropDownList(
        ArrayHelper::map(Video::find()->all(),'id','nombre'),
            ['prompt'=>'Escoja la pelicula para rentar']
            ) ?>

    <?= $form->field($detalle, 'monto')->textInput() ?>
    

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
