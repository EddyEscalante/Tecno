<?php

namespace backend\controllers;

use Yii;
use backend\models\Cumodulo;
use backend\models\CumoduloSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * CumoduloController implements the CRUD actions for Cumodulo model.
 */
class CumoduloController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Cumodulo models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new CumoduloSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Cumodulo model.
     * @param integer $id_cu
     * @param integer $id_modulo
     * @return mixed
     */
    public function actionView($id_cu, $id_modulo)
    {
        return $this->render('view', [
            'model' => $this->findModel($id_cu, $id_modulo),
        ]);
    }

    /**
     * Creates a new Cumodulo model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Cumodulo();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_cu' => $model->id_cu, 'id_modulo' => $model->id_modulo]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Cumodulo model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id_cu
     * @param integer $id_modulo
     * @return mixed
     */
    public function actionUpdate($id_cu, $id_modulo)
    {
        $model = $this->findModel($id_cu, $id_modulo);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_cu' => $model->id_cu, 'id_modulo' => $model->id_modulo]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Cumodulo model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id_cu
     * @param integer $id_modulo
     * @return mixed
     */
    public function actionDelete($id_cu, $id_modulo)
    {
        $this->findModel($id_cu, $id_modulo)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Cumodulo model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id_cu
     * @param integer $id_modulo
     * @return Cumodulo the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id_cu, $id_modulo)
    {
        if (($model = Cumodulo::findOne(['id_cu' => $id_cu, 'id_modulo' => $id_modulo])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
