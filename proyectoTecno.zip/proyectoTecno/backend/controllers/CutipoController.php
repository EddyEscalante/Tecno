<?php

namespace backend\controllers;

use Yii;
use backend\models\Cutipo;
use backend\models\CutipoSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * CutipoController implements the CRUD actions for Cutipo model.
 */
class CutipoController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Cutipo models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new CutipoSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Cutipo model.
     * @param integer $id_tipo
     * @param integer $id_cu
     * @return mixed
     */
    public function actionView($id_tipo, $id_cu)
    {
        return $this->render('view', [
            'model' => $this->findModel($id_tipo, $id_cu),
        ]);
    }

    /**
     * Creates a new Cutipo model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Cutipo();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_tipo' => $model->id_tipo, 'id_cu' => $model->id_cu]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Cutipo model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id_tipo
     * @param integer $id_cu
     * @return mixed
     */
    public function actionUpdate($id_tipo, $id_cu)
    {
        $model = $this->findModel($id_tipo, $id_cu);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id_tipo' => $model->id_tipo, 'id_cu' => $model->id_cu]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Cutipo model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id_tipo
     * @param integer $id_cu
     * @return mixed
     */
    public function actionDelete($id_tipo, $id_cu)
    {
        $this->findModel($id_tipo, $id_cu)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Cutipo model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id_tipo
     * @param integer $id_cu
     * @return Cutipo the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id_tipo, $id_cu)
    {
        if (($model = Cutipo::findOne(['id_tipo' => $id_tipo, 'id_cu' => $id_cu])) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
