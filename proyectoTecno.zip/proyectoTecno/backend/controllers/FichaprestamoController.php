<?php

namespace backend\controllers;

use Yii;
use backend\models\Fichaprestamo;
use backend\models\Detalle;
use backend\models\FichaprestamoSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * FichaprestamoController implements the CRUD actions for Fichaprestamo model.
 */
class FichaprestamoController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Fichaprestamo models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new FichaprestamoSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Fichaprestamo model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Fichaprestamo model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Fichaprestamo();
        $detalle = new Detalle();

        if ($model->load(Yii::$app->request->post()) && $detalle->load(Yii::$app->request->post())) {
            $model->save();
                       
            $detalle->nro_ficha= $model->nro;
            $detalle->save();
            return $this->redirect(['view', 'id' => $model->nro]);
        } else {
            return $this->render('create', [
                'model' => $model,
                'detalle'=> $detalle,
            ]);
        }
    }

    /**
     * Updates an existing Fichaprestamo model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->nro]);
        } else {
            return $this->render('update', [
                'model' => $model,                
            ]);
        }
    }

    /**
     * Deletes an existing Fichaprestamo model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Fichaprestamo model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Fichaprestamo the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Fichaprestamo::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
