<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "emails".
 *
 * @property integer $id
 * @property string $nombre_destino
 * @property string $correo_destino
 * @property string $tema
 * @property string $contenido
 */
class Emails extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'emails';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nombre_destino', 'correo_destino', 'tema', 'contenido'], 'required'],
            [['contenido'], 'string'],
            [['nombre_destino'], 'string', 'max' => 50],
            [['correo_destino', 'tema'], 'string', 'max' => 200],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nombre_destino' => 'Nombre Destino',
            'correo_destino' => 'Correo Destino',
            'tema' => 'Tema',
            'contenido' => 'Contenido',
        ];
    }
}
