<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "detalle".
 *
 * @property integer $nro_ficha
 * @property integer $id_video
 * @property integer $monto
 *
 * @property Video $idVideo
 * @property Fichaprestamo $nroFicha
 */
class Detalle extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'detalle';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nro_ficha', 'id_video', 'monto'], 'required'],
            [['nro_ficha', 'id_video', 'monto'], 'integer'],
            [['id_video'], 'exist', 'skipOnError' => true, 'targetClass' => Video::className(), 'targetAttribute' => ['id_video' => 'id']],
            [['nro_ficha'], 'exist', 'skipOnError' => true, 'targetClass' => Fichaprestamo::className(), 'targetAttribute' => ['nro_ficha' => 'nro']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'nro_ficha' => 'Nro Ficha',
            'id_video' => 'Id Video',
            'monto' => 'Monto',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdVideo()
    {
        return $this->hasOne(Video::className(), ['id' => 'id_video']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNroFicha()
    {
        return $this->hasOne(Fichaprestamo::className(), ['nro' => 'nro_ficha']);
    }
}
