<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "tipousuario".
 *
 * @property integer $ci_usuario
 * @property integer $id_tipo
 *
 * @property Usuario $ciUsuario
 * @property Tipo $idTipo
 */
class Tipousuario extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tipousuario';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ci_usuario', 'id_tipo'], 'required'],
            [['ci_usuario', 'id_tipo'], 'integer'],
            [['ci_usuario'], 'exist', 'skipOnError' => true, 'targetClass' => Usuario::className(), 'targetAttribute' => ['ci_usuario' => 'ci']],
            [['id_tipo'], 'exist', 'skipOnError' => true, 'targetClass' => Tipo::className(), 'targetAttribute' => ['id_tipo' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ci_usuario' => 'Ci Usuario',
            'id_tipo' => 'Id Tipo',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCiUsuario()
    {
        return $this->hasOne(Usuario::className(), ['ci' => 'ci_usuario']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdTipo()
    {
        return $this->hasOne(Tipo::className(), ['id' => 'id_tipo']);
    }
}
