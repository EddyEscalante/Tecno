<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "video".
 *
 * @property integer $id
 * @property string $nombre
 * @property integer $duracion
 * @property integer $costo
 * @property integer $estado
 * @property integer $id_tipovideo
 *
 * @property Detalle[] $detalles
 * @property Fichaprestamo[] $nroFichas
 * @property Tipovideo $idTipovideo
 */
class Video extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'video';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'nombre', 'duracion', 'costo', 'estado', 'id_tipovideo'], 'required'],
            [['id', 'duracion', 'costo', 'estado', 'id_tipovideo'], 'integer'],
            [['nombre'], 'string', 'max' => 50],
            [['id_tipovideo'], 'exist', 'skipOnError' => true, 'targetClass' => Tipovideo::className(), 'targetAttribute' => ['id_tipovideo' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nombre' => 'Nombre',
            'duracion' => 'Duracion',
            'costo' => 'Costo',
            'estado' => 'Estado',
            'id_tipovideo' => 'Id Tipovideo',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDetalles()
    {
        return $this->hasMany(Detalle::className(), ['id_video' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getNroFichas()
    {
        return $this->hasMany(Fichaprestamo::className(), ['nro' => 'nro_ficha'])->viaTable('detalle', ['id_video' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdTipovideo()
    {
        return $this->hasOne(Tipovideo::className(), ['id' => 'id_tipovideo']);
    }
}
