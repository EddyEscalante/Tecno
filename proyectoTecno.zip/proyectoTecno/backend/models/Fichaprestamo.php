<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "fichaprestamo".
 *
 * @property integer $nro
 * @property integer $ci_usuario
 * @property string $nombre
 * @property string $direccion
 * @property integer $dias
 * @property string $fecha
 *
 * @property Detalle[] $detalles
 * @property Video[] $idVideos
 * @property Usuario $ciUsuario
 */
class Fichaprestamo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'fichaprestamo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nro', 'ci_usuario', 'nombre', 'direccion', 'dias', 'fecha'], 'required'],
            [['nro', 'ci_usuario', 'dias'], 'integer'],
            [['fecha'], 'safe'],
            [['nombre'], 'string', 'max' => 50],
            [['direccion'], 'string', 'max' => 255],
            [['ci_usuario'], 'exist', 'skipOnError' => true, 'targetClass' => Usuario::className(), 'targetAttribute' => ['ci_usuario' => 'ci']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'nro' => 'Nro',
            'ci_usuario' => 'Ci Usuario',
            'nombre' => 'Nombre',
            'direccion' => 'Direccion',
            'dias' => 'Dias',
            'fecha' => 'Fecha',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDetalles()
    {
        return $this->hasMany(Detalle::className(), ['nro_ficha' => 'nro']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdVideos()
    {
        return $this->hasMany(Video::className(), ['id' => 'id_video'])->viaTable('detalle', ['nro_ficha' => 'nro']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCiUsuario()
    {
        return $this->hasOne(Usuario::className(), ['ci' => 'ci_usuario']);
    }
}
