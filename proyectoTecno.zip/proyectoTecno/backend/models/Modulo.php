<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "modulo".
 *
 * @property integer $id
 * @property string $nombre
 * @property integer $estado
 *
 * @property Cumodulo[] $cumodulos
 * @property Casouso[] $idCus
 */
class Modulo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'modulo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'nombre', 'estado'], 'required'],
            [['id', 'estado'], 'integer'],
            [['nombre'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nombre' => 'Nombre',
            'estado' => 'Estado',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCumodulos()
    {
        return $this->hasMany(Cumodulo::className(), ['id_modulo' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdCus()
    {
        return $this->hasMany(Casouso::className(), ['id' => 'id_cu'])->viaTable('cumodulo', ['id_modulo' => 'id']);
    }
}
