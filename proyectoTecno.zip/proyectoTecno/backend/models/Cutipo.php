<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "cutipo".
 *
 * @property integer $id_tipo
 * @property integer $id_cu
 * @property integer $estado
 *
 * @property Casouso $idCu
 * @property Tipo $idTipo
 */
class Cutipo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cutipo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_tipo', 'id_cu', 'estado'], 'required'],
            [['id_tipo', 'id_cu', 'estado'], 'integer'],
            [['id_cu'], 'exist', 'skipOnError' => true, 'targetClass' => Casouso::className(), 'targetAttribute' => ['id_cu' => 'id']],
            [['id_tipo'], 'exist', 'skipOnError' => true, 'targetClass' => Tipo::className(), 'targetAttribute' => ['id_tipo' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_tipo' => 'Id Tipo',
            'id_cu' => 'Id Cu',
            'estado' => 'Estado',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdCu()
    {
        return $this->hasOne(Casouso::className(), ['id' => 'id_cu']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdTipo()
    {
        return $this->hasOne(Tipo::className(), ['id' => 'id_tipo']);
    }
}
