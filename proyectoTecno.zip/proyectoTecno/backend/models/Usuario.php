<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "usuario".
 *
 * @property integer $ci
 * @property string $nombres
 * @property string $apellidos
 * @property integer $telefono
 * @property integer $estado
 *
 * @property Fichaprestamo[] $fichaprestamos
 * @property Tipousuario[] $tipousuarios
 * @property Tipo[] $idTipos
 */
class Usuario extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'usuario';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['ci', 'nombres', 'apellidos', 'telefono', 'estado'], 'required'],
            [['ci', 'telefono', 'estado'], 'integer'],
            [['nombres', 'apellidos'], 'string', 'max' => 200],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'ci' => 'Ci',
            'nombres' => 'Nombres',
            'apellidos' => 'Apellidos',
            'telefono' => 'Telefono',
            'estado' => 'Estado',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFichaprestamos()
    {
        return $this->hasMany(Fichaprestamo::className(), ['ci_usuario' => 'ci']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTipousuarios()
    {
        return $this->hasMany(Tipousuario::className(), ['ci_usuario' => 'ci']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdTipos()
    {
        return $this->hasMany(Tipo::className(), ['id' => 'id_tipo'])->viaTable('tipousuario', ['ci_usuario' => 'ci']);
    }
}
