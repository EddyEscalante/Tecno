<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "casouso".
 *
 * @property integer $id
 * @property string $nombre
 * @property integer $estado
 *
 * @property Cumodulo[] $cumodulos
 * @property Modulo[] $idModulos
 * @property Cutipo[] $cutipos
 * @property Tipo[] $idTipos
 */
class Casouso extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'casouso';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'nombre', 'estado'], 'required'],
            [['id', 'estado'], 'integer'],
            [['nombre'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nombre' => 'Nombre',
            'estado' => 'Estado',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCumodulos()
    {
        return $this->hasMany(Cumodulo::className(), ['id_cu' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdModulos()
    {
        return $this->hasMany(Modulo::className(), ['id' => 'id_modulo'])->viaTable('cumodulo', ['id_cu' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCutipos()
    {
        return $this->hasMany(Cutipo::className(), ['id_cu' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdTipos()
    {
        return $this->hasMany(Tipo::className(), ['id' => 'id_tipo'])->viaTable('cutipo', ['id_cu' => 'id']);
    }
}
