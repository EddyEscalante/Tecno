<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "tipovideo".
 *
 * @property integer $id
 * @property string $nombre
 * @property string $descripcion
 * @property integer $estado
 *
 * @property Video[] $videos
 */
class Tipovideo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tipovideo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'nombre', 'descripcion', 'estado'], 'required'],
            [['id', 'estado'], 'integer'],
            [['nombre', 'descripcion'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nombre' => 'Nombre',
            'descripcion' => 'Descripcion',
            'estado' => 'Estado',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getVideos()
    {
        return $this->hasMany(Video::className(), ['id_tipovideo' => 'id']);
    }
}
