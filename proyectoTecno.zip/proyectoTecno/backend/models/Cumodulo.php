<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "cumodulo".
 *
 * @property integer $id_cu
 * @property integer $id_modulo
 * @property integer $nroorden
 *
 * @property Casouso $idCu
 * @property Modulo $idModulo
 */
class Cumodulo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'cumodulo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id_cu', 'id_modulo', 'nroorden'], 'required'],
            [['id_cu', 'id_modulo', 'nroorden'], 'integer'],
            [['id_cu'], 'exist', 'skipOnError' => true, 'targetClass' => Casouso::className(), 'targetAttribute' => ['id_cu' => 'id']],
            [['id_modulo'], 'exist', 'skipOnError' => true, 'targetClass' => Modulo::className(), 'targetAttribute' => ['id_modulo' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id_cu' => 'Id Cu',
            'id_modulo' => 'Id Modulo',
            'nroorden' => 'Nroorden',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdCu()
    {
        return $this->hasOne(Casouso::className(), ['id' => 'id_cu']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdModulo()
    {
        return $this->hasOne(Modulo::className(), ['id' => 'id_modulo']);
    }
}
