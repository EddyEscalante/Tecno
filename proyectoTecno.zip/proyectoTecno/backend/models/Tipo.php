<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "tipo".
 *
 * @property integer $id
 * @property string $nombre
 * @property string $descripcion
 * @property integer $estado
 *
 * @property Cutipo[] $cutipos
 * @property Casouso[] $idCus
 * @property Tipousuario[] $tipousuarios
 * @property Usuario[] $ciUsuarios
 */
class Tipo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'tipo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'nombre', 'descripcion', 'estado'], 'required'],
            [['id', 'estado'], 'integer'],
            [['nombre', 'descripcion'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'nombre' => 'Nombre',
            'descripcion' => 'Descripcion',
            'estado' => 'Estado',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCutipos()
    {
        return $this->hasMany(Cutipo::className(), ['id_tipo' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getIdCus()
    {
        return $this->hasMany(Casouso::className(), ['id' => 'id_cu'])->viaTable('cutipo', ['id_tipo' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getTipousuarios()
    {
        return $this->hasMany(Tipousuario::className(), ['id_tipo' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCiUsuarios()
    {
        return $this->hasMany(Usuario::className(), ['ci' => 'ci_usuario'])->viaTable('tipousuario', ['id_tipo' => 'id']);
    }
}
